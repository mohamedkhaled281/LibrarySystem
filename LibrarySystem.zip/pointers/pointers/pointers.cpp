#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include <string>
#include <iostream>
using namespace std;
typedef struct book {
    int Id;
    char BookName[50];
    int Quantity;

}Book;

void insert_book(Book a[]);
void Delete_book(Book a[]);
void Do_Another(Book a[]);
int SearchById(Book a[],int );
int RECURSION_Search(Book a[], int id, int size);
void LinearSearch_usingRecursion(Book a[]);
void Binary_search(Book a[]);
void swap(Book*ptr1, Book *ptr2);
void Display_unsorted(Book a[]);
void Display_Sorted(Book a[]);
void Exit(FILE*,Book a[]);
void Bubble_sort(Book a[]);
int BinarySearchWithBubbleSort(Book a[], char b[]);
void Print_to_file(FILE* Fptr, Book a[]);
void ask_for_operation(Book a[]);
int counter = 0;
int Size = 0;
FILE* Lipraryptr;
int main() {
    int i=0, j=0,check=0,w=0,catcch=0;
    Book bookarray[50];
    char lineOfString[50],catchstring[50];
    Lipraryptr = fopen("Library.txt", "r+");
    fseek(Lipraryptr, 0, SEEK_SET);
    if (Lipraryptr != NULL) {
        for (int z = 0;z < 3;z++) {
            fscanf(Lipraryptr, "%d\t%[^\t]s", &bookarray[z].Id, bookarray[z].BookName);fscanf(Lipraryptr, "%d", &bookarray[z].Quantity);
            //printf("book name is:%s\nbook id is:%d\nbook quantity is:%d\n", bookarray[z].BookName, bookarray[z].Id, bookarray[z].Quantity);
            counter++;
            Size++;
        }
        printf("1)Insert a book \n2)delete a book \n3)search a book by id \n4)search book by name \n5)display books sorted \n6)display all books unsorted \n");
        scanf(" %d", &check);
        switch (check) {
        case 1:
            insert_book(bookarray);
            break;
        case 2:
            Delete_book(bookarray);
            break;
        case 3:
            LinearSearch_usingRecursion(bookarray);
            break;
        case 4:
            Binary_search(bookarray);
            break;
        case 5:
            Display_Sorted(bookarray);
            break;
        case 6:
            Display_unsorted(bookarray);
            break;
        default:
            printf("wrong number");
            Exit(Lipraryptr,bookarray);

        }
    }
    else printf("file not found");
 }

 void insert_book(Book a[]) {
     int x;
     char y;
     system("cls");
     printf("you chose to insert a book !\n");
     printf("enter ID ,Name and Quantity\n");
     scanf(" %d", &a[counter].Id);y = getchar();gets_s(a[counter].BookName);scanf("%d", &a[counter].Quantity);
     counter++;
     Size++;
     Print_to_file(Lipraryptr, a);
     ask_for_operation(a);
}
 void Delete_book(Book a[]) {
     int bookId,index,x;
     printf("you chose to Delete a book !\n");
     printf("enter book id ");
     scanf(" %d",&bookId);
     index=SearchById(a,bookId);
     if (index != -1) {
         for (int i = 0;i < counter-1;i++) {           
                 a[index] = a[index + 1];
                 index++;             
         }
     }
     else printf("this book is not in the library \n");
     counter--;
     Size--;
     Print_to_file(Lipraryptr, a);
     ask_for_operation(a);
 }
 int SearchById(Book a[],int bookid) {
     for (int i = 0;i < counter+1;i++) {
         if (a[i].Id == bookid) return i;
     }
       return -1;
 }
 int RECURSION_Search(Book a[], int x,   int size) {
     size -= 1;
     if (size < 0) return -1;
     else if  (a[size].Id == x )return size;
     else return RECURSION_Search(a, x, size);
 }
 void LinearSearch_usingRecursion(Book a[]) {
     int index = 0,Key,x;
     printf("enter book ID to search .....");
     scanf(" %d",&Key);
     index=RECURSION_Search(a, Key, Size);
     if (index != -1) {
         printf("book name is %s \n book id is %d \n book quantity is %d \n", a[index].BookName, a[index].Id,a[index].Quantity);
     }
     else printf("not found ");

     ask_for_operation(a);
 }
 void Binary_search(Book a[]) {
     int index,x;
     char y;
     char bookname[20];
     Book SortedBooks[50];
     for (int i = 0;i < counter;i++) {
         SortedBooks[i] = a[i];
     }
     printf("enter book name .... \n");
     y = getchar();gets_s(bookname);
     Bubble_sort(SortedBooks);
     index= BinarySearchWithBubbleSort(SortedBooks, bookname);
     if (index != -1) {
         printf("book name is : %s \n book id is :%d \n book quantity is :%d \n", SortedBooks[index].BookName, SortedBooks[index].Id, SortedBooks[index].Quantity);
     }
     else printf("Not found !");
     ask_for_operation(a);
 }
 int BinarySearchWithBubbleSort(Book a[],char b[]) {
     Bubble_sort(a);
     int low=0, middle, high=counter-1,x;
     while (low <= high) {
         middle = (high + low) / 2;
         x = strcmp(a[middle].BookName, b);
         if (x==0)return middle;
         else if (x > 0) high = middle - 1;
         else low = middle + 1;
     }
     return -1;
 }

 void Bubble_sort(Book a[]) {
     int check=0;
     for (int i = 0;i < counter;i++) {
         for (int x = 0;x < counter ;x++) {
             check = strcmp(a[x].BookName, a[x + 1].BookName);
             if (check>0) {
                 swap(a[x], a[x + 1]);
             }
         }
     }
 }

 void swap(Book ptr1 , Book ptr2) {
     Book tempptr=ptr1;
     ptr1 = ptr2;
     ptr2 = tempptr;
     tempptr.Id = ptr1.Id;
     tempptr.Quantity = ptr1.Quantity;
     strcpy(tempptr.BookName , ptr1.BookName);
     ptr1.Id = ptr2.Id;
     ptr1.Quantity = ptr2.Quantity;
     strcpy(ptr1.BookName, ptr2.BookName);
     ptr2.Id = tempptr.Id;
     ptr2.Quantity = tempptr.Quantity;
     strcpy(ptr2.BookName, tempptr.BookName);
 }

 void  Display_unsorted(Book a[]) {
     int x;
     for (int i = 0;i <counter;i++) {
         printf("book name is : %s\n book id is %d \n book quantity is %d \n",a[i].BookName,a[i].Id,a[i].Quantity);
     }
     ask_for_operation(a);
}
 void Display_Sorted(Book a[]) {
     Book SortedBooks[50];
     int x;
     for (int i = 0;i < counter;i++) {
         SortedBooks[i] = a[i];
     }
     Bubble_sort(SortedBooks);
     for (int i = 0;i < counter;i++) {
         printf("book name is :%s\n book id is:%d \n book quantity is:%d \n", SortedBooks[i].BookName, SortedBooks[i].Id, SortedBooks[i].Quantity);
     }
     ask_for_operation(a);
 }

void Do_Another(book bookarray[]){
    system("cls");
     int check;
     printf("1)Insert a book \n2)delete a book \n3)search a book by id \n4)search book by name \n5)display books sorted \n6)display all books unsorted\n");
     scanf(" %d",&check);

     switch (check) {
     case 1:
         insert_book(bookarray);
         break;
     case 2:
         Delete_book(bookarray);
         break;
     case 3:
         LinearSearch_usingRecursion(bookarray);
         break;
     case 4:
         Binary_search(bookarray);
         break;
     case 5:
         Display_Sorted(bookarray);
         break;
     case 6:
         Display_unsorted(bookarray);
         break;
     }
 }
void Exit(FILE*Fptr,Book a[]){
    printf("program will exit ..... \n");
    Print_to_file(Fptr, a);
    fclose(Fptr);
    exit(1);
}

 void Print_to_file(FILE* Fptr, Book a[]) {
     fclose(Fptr);
     Fptr = fopen("library.txt", "w");
     for (int i = 0;i < counter;i++) {
         fprintf(Fptr, "%d\t%s\t%d\n", a[i].Id, a[i].BookName, a[i].Quantity);
     }
     fclose(Fptr);
}

 void ask_for_operation(Book a[]) {
     char x[3],y;
     printf("do you want to do another operation ? \n press yes to continue and no to exit\n");
     scanf(" %s", &x);
     if (strcmp(x ,"yes")==0)Do_Another(a);
     else Exit(Lipraryptr, a);
 }





//for (int z = 0;z < 3;z++) {
//    fscanf(Lipraryptr, "%d\t%[^\t]s", &bookarray[z].Id, bookarray[z].BookName);fscanf(Lipraryptr, "%d", &bookarray[z].Quantity);
//    printf("book name is:%s\nbook id is:%d\nbook quantity is:%d\n", bookarray[z].BookName, bookarray[z].Id, bookarray[z].Quantity);
//    counter++;
//    Size++;
//}